<?php
defined('_JEXEC') or die;
?>
<h1><?php echo $this->message; ?></h1>
